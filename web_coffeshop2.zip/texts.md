# Encabezado

**Enlaces nav**

Recetas
Reservar una mesa
Contactos

**Título y descripción**

Café de especialidad en Triple Peaks
¡Te damos la bienvenida a nuestra zona de estudio! Aquí tenemos café para darte energía y motivar tu creatividad.

**Horarios y dirección**

Horario:
Lunes a Viernes (de 10:00h a 19:00h)
Sábados y Domingos (de 11:00h a 18:00h)

Avenida del Éxito 200, Ciudad Triple Peaks

---

## Sección: Recetas

**Título y descripción**

Recetas
Echa un vistazo a las recetas que hemos reunido para que elabores tus propios snacks.

**texto de iframe**

Receta en Aeropress
~5 min
Receta en cafetera francesa
~15 min

---

## Sección: Reserva

**Título y descripción**

Reservar una mesa

**Etiquetas del formulario**

Nombre *
Número de comensales *
Fecha y hora *
Tu correo electrónico *

Reservar una mesa

Acepto los términos de uso

**Marcadores de posición**

Nombre
1-8
email@email.com

---

## Pie de página


**Pie de página**

Redes sociales
Facebook
Instagram

© 2024 Tu nombre
